<?php
/**
 *               
 * @license   GNU General Public License version 2
 */

if (!defined('_PS_VERSION_')) {
    # module validation
    exit;
}

class BlogCategory
{
    # Validate module
}
